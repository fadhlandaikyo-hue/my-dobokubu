<script setup>
import { ref, computed } from "vue"
import { useRoute } from "vue-router"
import BaseNavbarHome from "../HomeComponents/NavbarHome.vue"
import BaseFooterHome from "../HomeComponents/FooterHome.vue"
import BaseButtonBack from "../Utilities/UtilitiesHome/ButtonBack.vue"
import BaseButtonBackConstruction from "../Utilities/UtilitiesHome/ButtonBackConstruction.vue"
import BaseProgressBarDetail from "../HomeComponents/ProgressBarDetail.vue"
import { useProgressColor } from "./composables/useProgressColor.js"
import { useLocalStorage } from "./composables/useLocalStorage.js"
import "./constructiondetail.css"

const route = useRoute()
const { saveOne, getOne } = useLocalStorage()
const { progressColor, statusLabel, badgeColor } = useProgressColor()

const CORRECT_PASSWORD = "191101"

const projectsRaw = [
  {
    id: 1,
    name: "美保(5)格納庫等新設舗装工事",
    code: "20250009",
    completionDate: "2023-11-08 - 2026-03-01",
    type: "道路",
    images: [{ src: "", takenAt: "2026-03-01" }],
    badgeLabel: null,
    badgeClass: null,
    completed: false,
    description: `-`,
    location: "-",
    contractor: "小島",
  },
  {
    id: 2,
    name: "鍵掛峠道路日南地区改良工事",
    code: "20260002",
    completionDate: "2024-05-01 - 2026-03-01",
    type: "道路",
    images: [
      { src: "/construction_img/日南/2024-08-28.webp", takenAt: "2024-08-28" },
      { src: "/construction_img/日南/2024-09-26.webp", takenAt: "2024-09-26" },
      { src: "/construction_img/日南/2024-10-23.webp", takenAt: "2024-10-23" },
      { src: "/construction_img/日南/2024-11-20.webp", takenAt: "2024-11-20" },
      { src: "/construction_img/日南/2024-12-17.webp", takenAt: "2024-12-17" },
      { src: "/construction_img/日南/2025-03-26.webp", takenAt: "2025-03-26" },
      { src: "/construction_img/日南/2025-04-25.webp", takenAt: "2025-04-25" },
      { src: "/construction_img/日南/2025-05-23.webp", takenAt: "2025-05-23" },
      { src: "/construction_img/日南/2025-06-30.webp", takenAt: "2025-06-30" },
      { src: "/construction_img/日南/2025-07-17.webp", takenAt: "2025-07-17" },
      { src: "/construction_img/日南/2025-08-19.webp", takenAt: "2025-08-19" },
      { src: "/construction_img/日南/2025-09-19.webp", takenAt: "2025-09-19" },
      { src: "/construction_img/日南/2025-10-17.webp", takenAt: "2025-10-17" },
      { src: "/construction_img/日南/2025-11-20.webp", takenAt: "2025-11-20" },
      { src: "/construction_img/日南/2025-12-23.webp", takenAt: "2025-12-23" },
      { src: "/construction_img/日南/2026-03-23.webp", takenAt: "2026-03-23" },
    ],
    badgeLabel: null,
    badgeClass: null,
    completed: false,
    description: `工事延長 L = 1,240m
    道路土工1式(掘削V=15,410m3、盛土 V = 15,190m3)
    法面工1式(植生工 A = 1 1,620m2、法枠工 A = 1,673m2)
    擁壁工1式重力式擁壁1式
    補強盛土工ジオテキスタイル補強土壁1式
    コンクリートブロック積工A=92m2
    排水構造物工1式
    舗装工1式下層路盤(C-40 t = 1 ) A = 3 3,800m2
    仮設工1式`,
    location: "-",
    contractor: "池岡、内田",
  },
  {
    id: 3,
    name: "奥陰田3地区急傾斜地崩壊 対策工事その2",
    code: "20250008",
    completionDate: "2025-07-15 - 2026-03-01",
    type: "砂防",
    images: [
      { src: "/construction_img/奥陰/2025-09-09.webp", takenAt: "2025-09-09" },
      { src: "/construction_img/奥陰/2025-09-22.webp", takenAt: "2025-09-22" },
      { src: "/construction_img/奥陰/2025-10-22.webp", takenAt: "2025-10-22" },
      { src: "/construction_img/奥陰/2025-11-20.webp", takenAt: "2025-11-20" },
      { src: "/construction_img/奥陰/2025-12-18.webp", takenAt: "2025-12-18" },
      { src: "/construction_img/奥陰/2026-01-19.webp", takenAt: "2026-01-19" },
      { src: "/construction_img/奥陰/2026-02-26.webp", takenAt: "2026-02-26" },
      { src: "/construction_img/奥陰/2026-03-26.webp", takenAt: "2026-03-26" },
    ],
    badgeLabel: null,
    badgeClass: null,
    completed: false,
    description: `施工延長L=43.7m
    砂防土工一式
    法面工一式
    仮設工一式`,
    location: "-",
    contractor: "長谷川、岩田ひ",
  },
  {
    id: 4,
    name: "中山3期営農飲雑用水 (高田工区)工事",
    code: "20250006",
    completionDate: "2025-09-09 - 2026-05-09",
    type: "管路工",
    images: [{ src: "", takenAt: "2026-05-09" }],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `管路工
    本線L=975.4m→962.7m
    A路線L=579.0m→578.7m
    B路線L=118.1m`,
    location: "-",
    contractor: "岩田こ",
  },
  {
    id: 5,
    name: "車尾五丁目ほか枝線工事",
    code: "20260006",
    completionDate: "2025-09-09 - 2026-09-30",
    type: "枝線",
    images: [{ src: "", takenAt: "2026-09-30" }],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `-`,
    location: "-",
    contractor: "西中",
  },
  {
    id: 6,
    name: "県道西伯伯太線(宮ノ前歩道橋) 橋梁塗装工事(2工区)(補助)",
    code: "20240009",
    completionDate: "2025-10-09 - 2026-03-06",
    type: "道橋",
    images: [
      { src: "/construction_img/宮ノ前/2025-11-21.webp", takenAt: "2026-11-26" },
      { src: "/construction_img/宮ノ前/2025-12-15.webp", takenAt: "2026-12-26" },
      { src: "/construction_img/宮ノ前/2026-03-11(1).webp", takenAt: "2026-03-11" },
      { src: "/construction_img/宮ノ前/2026-03-11(2).webp", takenAt: "2026-03-11" },
    ],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `宮ノ前歩道橋(2工区)
    橋長L=48.5m幅員W=2.9m
    施工延長L=16.2m
    橋梁塗替塗装工A=136m2
    孔食補修工一式
    仮設工一式`,
    location: "-",
    contractor: "今中",
  },
  {
    id: 7,
    name: "外港中野地区承水路護岸補修工事 (老朽化対策) (3工区)",
    code: "20240006",
    completionDate: "2026-02-20 - 2026-09-28",
    type: "老朽化対策",
    images: [{ src: "", takenAt: "2026-02-20" }],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `河川土工
    掘削工V=60m3
    法覆護岸工
    マットレス工L=157m
    大型ブロック積A=264m2
    張りコンクリートA=468m2
    排水構造物工
    プレキャストL型水路L=103m
    構造物撤去工
    コンクリート構造物取壊しV=108m3
    殼運搬V=108m3`,
    location: "-",
    contractor: "篠原",
  },
  {
    id: 8,
    name: "船越地区急傾斜地崩壊対策工事 (2工区)(交付金)(国補正)",
    code: "20250005",
    completionDate: "2026-02-27 - 2026-10-01",
    type: "崩壊対策",
    images: [{ src: "", takenAt: "2026-03-01" }],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `法面工
    簡易吹付法枠工(M-1500) A=508m2
    吹付法枠工(300×300) A = 4 471m2
    ノンフレーム工法 A = 3 318m2
    擁壁補強工
    鉄筋挿入工 ( L = 5 5.0m) N = 34本
    鉄筋挿入工 L = 4 ) N = 27本
    仮設工
    撤去 N = 1 式`,
    location: "Kita",
    contractor: "Main Contractor H",
  },
  {
    id: 9,
    name: "県道大山寺岸本線(小林工区) 電線共同溝設置工事(2工区)(補助)",
    code: "20250005",
    completionDate: "2026-03-10 - 2026-10-10",
    type: "共同溝設置",
    images: [{ src: "", takenAt: "2026-03-10" }],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `施工延長L=181.3m
    仮設工
    仮設舗装A=364m2
    舗装版撤去工一式
    開削土工一式
    電線共同溝
    管路L=176.8m
    S型マンホールN=1基
    通信接続桝N=1基`,
    location: "-",
    contractor: "西本",
  },
  {
    id: 10,
    name: "佐陀川砂防堰堤(K1)工事(9工区) (補助)(国補正) (2工区)(交付金)(国補正)",
    code: "20250005",
    completionDate: "2026-03-01 - 2026-12-15",
    type: "砂防堰堤",
    images: [
      { src: "/construction_img/佐陀/2026-03-11.webp", takenAt: "2026-03-11" },
    ],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `銅製砂防堰堤(K1)N=1基(H=12.0m、L=142m)
    砂防土工一式
    鋼製スリットW=55.2t
    垂直壁工V=113m3
    水叩工V=353m3
    護床工N=72個
    仮設工N=一式`,
    location: "-",
    contractor: "菊川",
  },
  {
    id: 11,
    name: "奥山川砂防堰堤工事(4工区) (交付金)(国補正)",
    code: "20250005",
    completionDate: "2026-03-16 - 2026-11-08",
    type: "砂防堰堤",
    images: [
      { src: "/construction_img/奥山/2026-03-16.webp", takenAt: "2026-03-16" },
    ],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `砂防土工
    埋戻し工V=1,790m3
    コンクリート堰堤工V=989m3`,
    location: "-",
    contractor: "内田",
  },
  {
    id: 12,
    name: "鍵掛峠道路新屋地区 第13改良工事",
    code: "20250005",
    completionDate: "2026-02-06 - 2027-05-08",
    type: "道路",
    images: [
      { src: "/construction_img/新屋/2026-04-08(1).webp", takenAt: "2026-04-08" },
      { src: "/construction_img/新屋/2026-04-08(2).webp", takenAt: "2026-04-08" },
    ],
    badgeLabel: null,
    badgeClass: null,
    completed: true,
    description: `-`,
    location: "-",
    contractor: "池岡",
  },
]

const projectId = Number(route.params.id)
const raw = projectsRaw.find((p) => p.id === projectId)
const persisted = raw ? getOne(raw.id, raw.defaultProgress) : 0
const project = ref(raw ? { ...raw, draft: persisted, saved: persisted } : null)

const isDirty = computed(() => project.value && project.value.draft !== project.value.saved)

const projectImages = computed(() => {
  if (!project.value) return []
  if (project.value.images?.length) {
    return project.value.images.map((img) =>
        typeof img === "string" ? { src: img, takenAt: null } : img,
    )
  }
  if (project.value.img) {
    return [{ src: project.value.img, takenAt: null }]
  }
  return [{ src: "/building.svg", takenAt: null }]
})

function parseISODate(str) {
  if (!str) return ""
  const candidate = str.trim()
  return /^\d{4}-\d{2}-\d{2}$/.test(candidate) ? candidate : ""
}

function formatDisplayDate(value) {
  if (!value) return "-"
  const date = new Date(`${value}T00:00:00`)
  if (Number.isNaN(date.getTime())) return value
  return date.toLocaleDateString("ja-JP", {
    year: "numeric",
    month: "short",
    day: "2-digit",
  })
}

function splitCompletionDate(value) {
  const normalized = (value || "").replace(/[–—]/g, "-")
  const parts = normalized.split(/\s+-\s+/)
  return {
    start: parts[0]?.trim() ?? "",
    end: parts[1]?.trim() ?? "",
  }
}

function displayDateRange(value) {
  const { start, end } = splitCompletionDate(value)
  if (!start && !end) return "-"
  return `${formatDisplayDate(start)} - ${formatDisplayDate(end)}`
}

const showDateModal = ref(false)
const draftStartDate = ref("")
const draftEndDate = ref("")
const pendingSaveType = ref("")

function openDateModal() {
  const { start, end } = splitCompletionDate(project.value.completionDate)
  draftStartDate.value = parseISODate(start)
  draftEndDate.value = parseISODate(end)
  showDateModal.value = true
}

function closeDateModal() {
  showDateModal.value = false
}

function confirmDateModal() {
  showDateModal.value = false
  pendingSaveType.value = isDirty.value ? "both" : "date"
  openPasswordModal()
}

const showModal = ref(false)
const passwordInput = ref("")
const passwordError = ref("")
const showPassword = ref(false)
const isShaking = ref(false)
const saveSuccess = ref(false)

function openPasswordModal() {
  passwordInput.value = ""
  passwordError.value = ""
  showPassword.value = false
  showModal.value = true

  setTimeout(() => {
    document.getElementById("pw-input")?.focus()
  }, 100)
}

function closeModal() {
  showModal.value = false
  passwordInput.value = ""
  passwordError.value = ""
}

function confirmSave() {
  if (passwordInput.value === CORRECT_PASSWORD) {
    if (pendingSaveType.value === "progress" || pendingSaveType.value === "both" || isDirty.value) {
      saveOne(project.value.id, project.value.draft)
      project.value.saved = project.value.draft
    }

    if (pendingSaveType.value === "date" || pendingSaveType.value === "both") {
      project.value.completionDate = `${draftStartDate.value} - ${draftEndDate.value}`
    }

    pendingSaveType.value = ""
    showModal.value = false
    passwordInput.value = ""
    passwordError.value = ""
    saveSuccess.value = true

    setTimeout(() => {
      saveSuccess.value = false
    }, 2500)
  } else {
    passwordError.value = "Incorrect password. Please try again."
    isShaking.value = true

    setTimeout(() => {
      isShaking.value = false
    }, 500)

    passwordInput.value = ""
    document.getElementById("pw-input")?.focus()
  }
}

function discard() {
  if (!project.value) return
  project.value.draft = project.value.saved
}

function onModalKeydown(event) {
  if (event.key === "Enter") confirmSave()
  if (event.key === "Escape") closeModal()
}
</script>

<template>
  <BaseNavbarHome />

  <div v-if="!project" class="min-h-screen flex items-center justify-center">
    <div class="text-center">
      <p class="text-2xl font-bold text-gray-700 mb-4">Project not found</p>
      <BaseButtonBack />
    </div>
  </div>

  <div v-else class="min-h-screen bg-gray-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <BaseButtonBackConstruction />

      <div class="flex snap-x snap-mandatory overflow-x-auto gap-4 px-8 mt-4 pb-2">
        <div
            v-for="(img, idx) in projectImages"
            :key="idx"
            class="snap-center shrink-0 w-72 sm:w-80 relative"
        >
          <img
              :src="img.src"
              :alt="`${project.name} - ${idx + 1}`"
              class="w-full h-48 object-cover rounded-xl"
              @error="(e) => (e.target.style.display = 'none')"
              loading="lazy"
          />
          <div class="absolute bottom-2 left-2 right-2 flex items-center justify-between gap-2">
            <span class="text-xs font-bold text-white bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded-full">
              {{ idx + 1 }} / {{ projectImages.length }}
            </span>
            <span
                v-if="img.takenAt"
                class="flex items-center gap-1 text-xs font-semibold text-white bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded-full"
            >
              <svg class="w-3 h-3 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              {{ formatDisplayDate(img.takenAt) }}
            </span>
          </div>
        </div>
      </div>

      <div class="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2 space-y-6">
          <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h2 class="text-lg font-bold text-gray-800 mb-3">工事概要</h2>
            <p class="text-gray-600 leading-relaxed whitespace-pre-line">{{ project.description }}</p>
          </div>

          <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h2 class="text-lg font-bold text-gray-800 mb-4">基本情報</h2>
            <div class="grid grid-cols-2 gap-6">
              <div>
                <p class="text-xs text-gray-400 uppercase font-semibold mb-1">工事種別</p>
                <p class="text-sm font-medium text-gray-800">{{ project.type }}</p>
              </div>
              <div>
                <p class="text-xs text-gray-400 uppercase font-semibold mb-1">
                  {{ project.completed ? "完成日" : "完成予定日" }}
                </p>
                <button
                    class="text-sm font-medium text-blue-600 hover:text-blue-800 underline underline-offset-2 transition-colors text-left"
                    @click="openDateModal"
                >
                  {{ displayDateRange(project.completionDate) }}
                </button>
              </div>
              <div>
                <p class="text-xs text-gray-400 uppercase font-semibold mb-1">施工場所</p>
                <p class="text-sm font-medium text-gray-800">{{ project.location }}</p>
              </div>
              <div>
                <p class="text-xs text-gray-400 uppercase font-semibold mb-1">担当者</p>
                <p class="text-sm font-medium text-gray-800">{{ project.contractor }}</p>
              </div>
            </div>
          </div>
        </div>

        <div class="space-y-4">
          <div
              class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 transition-colors duration-300"
              :style="{ borderTopColor: badgeColor(project.draft), borderTopWidth: '4px' }"
          >
            <h2 class="text-lg font-bold text-gray-800 mb-4">進捗状況</h2>

            <div class="flex justify-between text-sm font-medium text-gray-600 mb-1">
              <span class="flex items-center gap-1.5">
                {{ statusLabel(project.draft) }}
                <span
                    v-if="isDirty"
                    class="text-xs font-semibold px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 border border-amber-300"
                >
                  Unsaved
                </span>
              </span>
              <span :style="{ color: progressColor(project.draft) }">{{ project.draft }}%</span>
            </div>

            <BaseProgressBarDetail v-model="project.draft" class="mb-4" />

            <div v-if="isDirty" class="flex gap-2 mt-2">
              <button
                  @click="openPasswordModal"
                  class="flex-1 py-2 px-3 rounded-lg text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors duration-150 flex items-center justify-center gap-1.5"
              >
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                  />
                </svg>
                Save
              </button>
              <button
                  @click="discard"
                  class="flex-1 py-2 px-3 rounded-lg text-sm font-semibold bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors duration-150"
              >
                Reset
              </button>
            </div>

            <Transition name="fade">
              <div
                  v-if="saveSuccess"
                  class="mt-3 flex items-center gap-2 text-xs font-semibold text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-2"
              >
                <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
                Changes saved
              </div>
            </Transition>

            <p v-if="!isDirty && !saveSuccess" class="text-xs text-gray-400 mt-2 text-center">
              バーをドラッグして進捗を更新できます
            </p>
          </div>

          <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-4">
            <h3 class="text-sm font-bold text-gray-700 mb-3">Status Legend</h3>
            <div class="space-y-2 text-xs">
              <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-red-400 inline-block"></span>
                <span class="text-gray-600">計画 (0-24%)</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-blue-500 inline-block"></span>
                <span class="text-gray-600">進行中 (25-99%)</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-green-500 inline-block"></span>
                <span class="text-gray-600">完成 (100%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <Teleport to="body">
    <Transition name="modal">
      <div v-if="showDateModal" class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" @click="closeDateModal" />

        <div class="modal-box relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
          <div class="flex items-center gap-3 mb-5">
            <div class="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center shrink-0">
              <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
            </div>
            <div>
              <h3 class="text-base font-bold text-gray-900">期間を変更</h3>
              <p class="text-xs text-gray-500">工事の開始日と終了日を選択してください</p>
            </div>
          </div>

          <div class="bg-gray-50 rounded-xl px-4 py-2.5 mb-5 text-xs text-gray-500">
            <span class="font-semibold text-gray-700">現在:</span>
            {{ displayDateRange(project?.completionDate) }}
          </div>

          <div class="space-y-4">
            <div>
              <label class="block text-xs font-semibold text-gray-600 mb-1.5">
                <span class="inline-block w-2 h-2 rounded-full bg-green-400 mr-1.5"></span>
                開始日
              </label>
              <input
                  v-model="draftStartDate"
                  type="date"
                  class="w-full rounded-xl border border-gray-300 bg-white px-4 py-2.5 text-sm outline-none focus:border-indigo-500 transition-colors duration-150"
              />
            </div>

            <div class="flex items-center justify-center text-gray-300">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
              </svg>
            </div>

            <div>
              <label class="block text-xs font-semibold text-gray-600 mb-1.5">
                <span class="inline-block w-2 h-2 rounded-full bg-red-400 mr-1.5"></span>
                終了日
              </label>
              <input
                  v-model="draftEndDate"
                  type="date"
                  :min="draftStartDate"
                  class="w-full rounded-xl border border-gray-300 bg-white px-4 py-2.5 text-sm outline-none focus:border-indigo-500 transition-colors duration-150"
              />
            </div>
          </div>

          <div
              v-if="draftStartDate && draftEndDate"
              class="mt-4 bg-indigo-50 border border-indigo-100 rounded-xl px-4 py-2.5 text-xs text-indigo-700 font-medium"
          >
            {{ formatDisplayDate(draftStartDate) }} - {{ formatDisplayDate(draftEndDate) }}
          </div>

          <div class="flex gap-2 mt-5">
            <button
                @click="closeDateModal"
                class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors duration-150"
            >
              キャンセル
            </button>
            <button
                @click="confirmDateModal"
                :disabled="!draftStartDate || !draftEndDate"
                class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-indigo-600 text-white hover:bg-indigo-700 transition-colors duration-150 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
            >
              続く
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>

  <Teleport to="body">
    <Transition name="modal">
      <div
          v-if="showModal"
          class="fixed inset-0 z-50 flex items-center justify-center p-4"
          @keydown="onModalKeydown"
      >
        <div class="absolute inset-0 bg-black/50 backdrop-blur-sm" @click="closeModal" />

        <div
            class="modal-box relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6"
            :class="{ shake: isShaking }"
        >
          <div class="flex items-center gap-3 mb-5">
            <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
              <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
            <div>
              <h3 class="text-base font-bold text-gray-900">認証が必要です</h3>
              <p class="text-xs text-gray-500">進捗を保存するにはパスワードを入力してください</p>
            </div>
          </div>

          <div class="bg-gray-50 rounded-xl px-4 py-3 mb-5 text-sm">
            <p class="text-gray-500 text-xs mb-1">保存内容</p>
            <p class="font-semibold text-gray-800">{{ project?.name }}</p>
            <p v-if="pendingSaveType === 'date' || pendingSaveType === 'both'" class="text-gray-500 text-xs mt-0.5">
              期間:
              <span class="font-semibold text-gray-700">
                {{ formatDisplayDate(draftStartDate) }} - {{ formatDisplayDate(draftEndDate) }}
              </span>
            </p>
            <p
                v-if="pendingSaveType === 'progress' || pendingSaveType === 'both' || (!pendingSaveType && isDirty)"
                class="text-gray-500 text-xs mt-0.5"
            >
              Progress:
              <span class="font-semibold" :style="{ color: progressColor(project?.draft) }">{{ project?.draft }}%</span>
              ({{ statusLabel(project?.draft) }})
            </p>
          </div>

          <label class="block text-xs font-semibold text-gray-600 mb-1.5">パスワード</label>
          <div class="relative">
            <input
                id="pw-input"
                v-model="passwordInput"
                :type="showPassword ? 'text' : 'password'"
                placeholder="パスワードを入力..."
                class="w-full rounded-xl border px-4 py-2.5 text-sm pr-10 outline-none transition-colors duration-150"
                :class="
                passwordError
                  ? 'border-red-400 bg-red-50 focus:border-red-500'
                  : 'border-gray-300 bg-white focus:border-blue-500'
              "
                @keydown.enter="confirmSave"
            />
            <button
                type="button"
                @click="showPassword = !showPassword"
                class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                tabindex="-1"
            >
              <svg v-if="!showPassword" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                />
              </svg>
              <svg v-else class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                />
              </svg>
            </button>
          </div>

          <Transition name="fade">
            <p v-if="passwordError" class="mt-2 text-xs text-red-600 flex items-center gap-1">
              <svg class="w-3.5 h-3.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path
                    fill-rule="evenodd"
                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                    clip-rule="evenodd"
                />
              </svg>
              {{ passwordError }}
            </p>
          </Transition>

          <div class="flex gap-2 mt-5">
            <button
                @click="closeModal"
                class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors duration-150"
            >
              キャンセル
            </button>
            <button
                @click="confirmSave"
                class="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-blue-600 text-white hover:bg-blue-700 transition-colors duration-150"
            >
              確認して保存
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>

  <BaseFooterHome />
</template>