﻿<script setup>
import {ref, onMounted, onUnmounted} from 'vue'

// Logic state
const activeIndex = ref(0)
const totalImages = 4 // Samakan dengan jumlah gambar di template
let intervalId = null // Variable untuk menyimpan timer

// Logic Next Slide
const next = () => {
  if (activeIndex.value === totalImages - 1) {
    activeIndex.value = 0
  } else {
    activeIndex.value++
  }
}

// Logic Prev Slide
const prev = () => {
  if (activeIndex.value === 0) {
    activeIndex.value = totalImages - 1
  } else {
    activeIndex.value--
  }
}

// --- FITUR AUTOPLAY ---

// Fungsi untuk memulai timer
const startAutoSlide = () => {
  // Cegah multiple interval berjalan bersamaan
  stopAutoSlide()
  // Set interval setiap 3000ms (3 detik)
  intervalId = setInterval(() => {
    next()
  }, 5000)
}

// Fungsi untuk mematikan timer
const stopAutoSlide = () => {
  if (intervalId) {
    clearInterval(intervalId)
    intervalId = null
  }
}

// Jalankan saat komponen dimuat
onMounted(() => {
  startAutoSlide()
})

// Matikan saat komponen dihancurkan (ganti halaman) untuk mencegah memory leak
onUnmounted(() => {
  stopAutoSlide()
})
</script>

<template>
  <div class="text-center mb-8 md:mb-10" style="opacity: 1; transform: none;">
    <h2 class="text-[32px] uppercase font-semibold mb-4 pb-10 md:pb-0 "/>
    <p class="text-gray-600 max-w-2xl mx-auto"></p>
  </div>
  <div class="flex items-center justify-center min-h-[420px] bg-gray-100 p-4 md:min-h-[520px]">

    <div class="relative w-full max-w-4xl group overflow-hidden rounded-2xl shadow-2xl" @mouseenter="stopAutoSlide"
         @mouseleave="startAutoSlide">
      <div class="flex transition-transform duration-700 ease-in-out h-64 md:h-96"
           :style="{ transform: `translateX(-${activeIndex * 100}%)` }">
        <div class="w-full flex-shrink-0 relative">
          <a href="https://www.daikyou-g.co.jp/index.php">
            <img src="/img/unnamed.webp" class="w-full h-full object-cover" alt="Slide 1">
          </a>

        </div>

        <div class="w-full flex-shrink-0 relative">
          <a href="https://daikyou-g.dn-cloud.com/cgi-bin/dneo/dneo.cgi?cmd=login">
            <img src="/img/desknet-neo-login.png" class="w-full h-full object-cover" alt="Slide 2">
          </a>
        </div>

        <div class="w-full flex-shrink-0 relative">
          <a href="https://auth.genbacloud.com/login/conne-space">
            <img src="/img/genba-cloud-login.png" class="w-full h-full object-cover" alt="Slide 3">
          </a>
        </div>

        <div class="w-full flex-shrink-0 relative">
          <iframe loading="lazy" style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; border: none; padding: 0;margin: 0;"
                  src="https://www.canva.com/design/DAG0nukdNuc/JXjc5a4vdGCHn7Cc0Fcr1A/view?embed" allow="fullscreen">
          </iframe>
        </div>

      </div>

      <button @click="prev"
              class="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/60 text-white p-2 rounded-full backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
             class="w-6 h-6">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5"/>
        </svg>
      </button>

      <button @click="next"
              class="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/60 text-white p-2 rounded-full backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
             class="w-6 h-6">
          <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5"/>
        </svg>
      </button>

      <div class="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
        <button v-for="idx in totalImages" :key="idx" @click="activeIndex = idx - 1"
                class="h-2 rounded-full transition-all duration-300"
                :class="activeIndex === idx - 1 ? 'w-8 bg-white' : 'w-2 bg-white/50 hover:bg-white/80'"></button>
      </div>

      <div class="absolute bottom-0 left-0 h-1 bg-white/30 w-full">
        <div :key="activeIndex" class="h-full bg-white animate-load"></div>
      </div>

    </div>
  </div>
</template>

<style scoped>

</style>


